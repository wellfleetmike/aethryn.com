# rules

Empty on purpose. The SRD is sourced, not vendored.

    SRD 5.2 PDF, CC-BY-4.0, Wizards of the Coast
    https://media.dndbeyond.com/compendium-images/srd/5.2/SRD_CC_v5.2.pdf
    sha256 cf18e1f88a360646940b6fada63fd1bd04c1c02581ca668a9115c2f4577bf8aa
    5953304 bytes, 361 pages

Structured JSON of SRD 5.2 classes, subclasses, features, levels,
equipment, and magic items:

    5e-bits/5e-database, src/2024/en/, pinned commit d3e333bb

No SRD 5.2 spells JSON exists. The monsters file is a three-entry stub.
For spells and monsters the PDF is the only source. Extraction into our own
JSON is legal under CC-BY-4.0 and is a build for after a session has
happened.

Verify after downloading. Content decides, the filename never does.
