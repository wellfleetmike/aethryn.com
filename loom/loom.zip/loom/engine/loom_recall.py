#!/usr/bin/env python3
"""loom_recall -- persistent personalized semantic memory for the table.

One file. No required dependencies. Runs offline. The database lives beside
this file, so the whole thing relocates by copying the directory.

WHY THIS EXISTS
    Keyword search finds the word. A table needs the thing that was meant.
    Bailey says "the guy at the bridge" three sessions later. FTS5 misses it
    because the log says "toll keeper." Semantic retrieval finds it.

WHAT IT KNOWS
    Every memory has a SUBJECT (whose thread it belongs to), a KIND
    (HAPPENED / IMPROVISED / CLAIMED), and a SESSION. Retrieval is
    personalized: ask for Bailey and her thread outranks everyone else's.

EMBEDDINGS
    Primary  : ollama at localhost:11434, model nomic-embed-text.
    Fallback : hashed character-ngram vectors, pure stdlib. Weaker, but it
               is semantic-ish and it never fails to load.
    Hybrid   : semantic cosine + FTS5 keyword + recency + subject boost.

CLI
    python3 loom_recall.py write --subject Bailey --kind HAPPENED \\
        --text "Talked the toll keeper out of the bridge fee" --session 1
    python3 loom_recall.py recall "the guy at the bridge" --subject Bailey
    python3 loom_recall.py brief Bailey
    python3 loom_recall.py selftest
"""

import hashlib
import json
import math
import os
import re
import sqlite3
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB_PATH = HERE / "loom_recall.db"

KINDS = ("HAPPENED", "IMPROVISED", "CLAIMED")

OLLAMA_URL = os.environ.get("LOOM_OLLAMA", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("LOOM_EMBED_MODEL", "nomic-embed-text")
FALLBACK_DIM = 512

_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id          INTEGER PRIMARY KEY,
    session     INTEGER NOT NULL DEFAULT 0,
    subject     TEXT    NOT NULL DEFAULT '',
    kind        TEXT    NOT NULL DEFAULT 'HAPPENED',
    text        TEXT    NOT NULL,
    tags        TEXT    NOT NULL DEFAULT '',
    weight      REAL    NOT NULL DEFAULT 1.0,
    created_at  TEXT    NOT NULL,
    source      TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_subject ON memories(subject);
CREATE INDEX IF NOT EXISTS idx_session ON memories(session);

CREATE TABLE IF NOT EXISTS vectors (
    id      INTEGER PRIMARY KEY,
    dim     INTEGER NOT NULL,
    backend TEXT    NOT NULL,
    vec     BLOB    NOT NULL
);

CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    text, subject, tags, content='memories', content_rowid='id'
);
CREATE TRIGGER IF NOT EXISTS mem_ai AFTER INSERT ON memories BEGIN
    INSERT INTO memories_fts(rowid, text, subject, tags)
    VALUES (new.id, new.text, new.subject, new.tags);
END;
CREATE TRIGGER IF NOT EXISTS mem_ad AFTER DELETE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, text, subject, tags)
    VALUES ('delete', old.id, old.text, old.subject, old.tags);
END;
CREATE TRIGGER IF NOT EXISTS mem_au AFTER UPDATE ON memories BEGIN
    INSERT INTO memories_fts(memories_fts, rowid, text, subject, tags)
    VALUES ('delete', old.id, old.text, old.subject, old.tags);
    INSERT INTO memories_fts(rowid, text, subject, tags)
    VALUES (new.id, new.text, new.subject, new.tags);
END;
"""


# ---------------------------------------------------------------- embeddings

def _ollama_embed(text):
    """Return a list of floats, or None if ollama is not reachable."""
    body = json.dumps({"model": OLLAMA_MODEL, "prompt": text}).encode()
    req = urllib.request.Request(
        OLLAMA_URL.rstrip("/") + "/api/embeddings",
        data=body,
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            v = json.loads(r.read().decode()).get("embedding")
            return v if v else None
    except Exception:
        return None


_WORD = re.compile(r"[a-z0-9']+")

# Common words carry almost no retrieval signal but dominate a bag-of-tokens
# vector. "who guarded the door" must not match on "who". Dropped from the
# word channel; character ngrams still see them, at low weight.
_STOP = frozenset("""
a an and are as at be been but by can did do does for from get got had has
have he her hers him his how i if in into is it its me my not of on one or
our out over said she so than that the their them then there these they this
to too up was we were what when where which who whom why will with would you
your
""".split())


def _tokens(text):
    """Return (word_tokens, ngram_tokens). Words carry the meaning."""
    words = [w for w in _WORD.findall(text.lower()) if w not in _STOP]
    grams = []
    for w in words:
        p = "  " + w + "  "
        for n in (3, 4):
            for i in range(len(p) - n + 1):
                grams.append(p[i:i + n])
    return words, grams


def _fallback_embed(text):
    """Hashed vector, pure stdlib, deterministic, offline.

    Two channels. Whole words at full weight carry the topic; character
    ngrams at reduced weight carry morphology, so "door" reaches "doorway"
    and a typo still lands near its target.
    """
    vec = [0.0] * FALLBACK_DIM
    words, grams = _tokens(text)
    for toks, w in ((words, 1.0), (grams, 0.35)):
        for tok in toks:
            h = hashlib.blake2b(tok.encode(), digest_size=8).digest()
            idx = int.from_bytes(h[:4], "big") % FALLBACK_DIM
            vec[idx] += w if (h[4] & 1) else -w
    n = math.sqrt(sum(x * x for x in vec)) or 1.0
    return [x / n for x in vec]


def embed(text):
    """Return (vector, backend_name)."""
    v = _ollama_embed(text)
    if v:
        n = math.sqrt(sum(x * x for x in v)) or 1.0
        return [x / n for x in v], "ollama:" + OLLAMA_MODEL
    return _fallback_embed(text), "ngram"


def _pack(vec):
    import array
    return array.array("f", vec).tobytes()


def _unpack(blob):
    import array
    a = array.array("f")
    a.frombytes(blob)
    return list(a)


def _cosine(a, b):
    if len(a) != len(b):
        return 0.0
    return sum(x * y for x, y in zip(a, b))


# ---------------------------------------------------------------------- core

def connect():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(str(DB_PATH))
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.executescript(_SCHEMA)
    return c


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def write(text, subject="", kind="HAPPENED", session=0, tags=None,
          weight=1.0, source=""):
    """Store one memory. Returns its row id.

    IMPROVISED is canon the moment it is spoken -- write it before the next
    beat. CLAIMED is a player's assertion and gets checked before it is
    trusted.
    """
    if kind not in KINDS:
        raise ValueError("kind must be one of " + ", ".join(KINDS))
    tag_s = ",".join(t.strip() for t in (tags or []) if t.strip())
    vec, backend = embed(text)
    c = connect()
    try:
        cur = c.execute(
            "INSERT INTO memories(session,subject,kind,text,tags,weight,"
            "created_at,source) VALUES (?,?,?,?,?,?,?,?)",
            (session, subject, kind, text, tag_s, weight, _now(), source))
        mid = cur.lastrowid
        c.execute("INSERT INTO vectors(id,dim,backend,vec) VALUES (?,?,?,?)",
                  (mid, len(vec), backend, _pack(vec)))
        c.commit()
        return mid
    finally:
        c.close()


def _fts_hits(c, query, limit):
    """Return {id: normalized_keyword_score}. Never raises on odd input."""
    q = " OR ".join(_tokens(query)[0]) or query
    try:
        rows = c.execute(
            "SELECT rowid, rank FROM memories_fts WHERE memories_fts MATCH ? "
            "ORDER BY rank LIMIT ?", (q, limit)).fetchall()
    except sqlite3.OperationalError:
        return {}
    if not rows:
        return {}
    worst = min(r["rank"] for r in rows)
    return {r["rowid"]: (r["rank"] / worst if worst else 0.0) for r in rows}


def recall(query, subject=None, session=None, kinds=None, limit=5,
           subject_boost=0.15, recency_boost=0.10):
    """Hybrid retrieval. Returns rows ordered by score, highest first.

    score = 0.70 * semantic + 0.30 * keyword
          + subject_boost if the memory belongs to this player
          + recency_boost * (how recent, 0..1)
          then scaled by the memory's own weight.
    """
    qv, _ = embed(query)
    c = connect()
    try:
        sql = ("SELECT m.*, v.vec AS vec FROM memories m "
               "LEFT JOIN vectors v ON v.id = m.id WHERE 1=1")
        args = []
        if session is not None:
            sql += " AND m.session = ?"
            args.append(session)
        if kinds:
            sql += " AND m.kind IN (%s)" % ",".join("?" * len(kinds))
            args.extend(kinds)
        rows = c.execute(sql, args).fetchall()
        if not rows:
            return []

        kw = _fts_hits(c, query, 50)
        newest = max(r["id"] for r in rows)
        oldest = min(r["id"] for r in rows)
        span = (newest - oldest) or 1

        scored = []
        for r in rows:
            sem = _cosine(qv, _unpack(r["vec"])) if r["vec"] else 0.0
            s = 0.70 * sem + 0.30 * kw.get(r["id"], 0.0)
            if subject and r["subject"] and \
                    r["subject"].lower() == subject.lower():
                s += subject_boost
            s += recency_boost * ((r["id"] - oldest) / span)
            s *= r["weight"]
            d = dict(r)
            d.pop("vec", None)
            d["score"] = round(s, 4)
            d["semantic"] = round(sem, 4)
            scored.append(d)

        scored.sort(key=lambda d: d["score"], reverse=True)
        return scored[:limit]
    finally:
        c.close()


def brief(subject, limit=6):
    """What Loom says out loud before a session starts.

    Not a search. The specific things that make a returning player feel
    known: what they did, what they were proud of, what they said they
    wanted to do next.
    """
    c = connect()
    try:
        rows = c.execute(
            "SELECT * FROM memories WHERE lower(subject)=lower(?) "
            "ORDER BY session DESC, id DESC", (subject,)).fetchall()
    finally:
        c.close()
    if not rows:
        return None

    want = [r for r in rows if "next" in r["tags"]]
    proud = [r for r in rows if "proud" in r["tags"]]
    did = [r for r in rows if r["kind"] == "HAPPENED"]
    last = rows[0]["session"]

    return {
        "subject": rows[0]["subject"],
        "last_session": last,
        "total": len(rows),
        "did": [r["text"] for r in did[:limit]],
        "proud": [r["text"] for r in proud[:2]],
        "wants": [r["text"] for r in want[:2]],
    }


def stats():
    c = connect()
    try:
        n = c.execute("SELECT COUNT(*) n FROM memories").fetchone()["n"]
        by_kind = {r["kind"]: r["c"] for r in c.execute(
            "SELECT kind, COUNT(*) c FROM memories GROUP BY kind")}
        by_subj = {r["subject"] or "(table)": r["c"] for r in c.execute(
            "SELECT subject, COUNT(*) c FROM memories GROUP BY subject")}
        backends = {r["backend"]: r["c"] for r in c.execute(
            "SELECT backend, COUNT(*) c FROM vectors GROUP BY backend")}
        return {"total": n, "by_kind": by_kind, "by_subject": by_subj,
                "backends": backends, "db": str(DB_PATH)}
    finally:
        c.close()


# ------------------------------------------------------------------ selftest

ROLE_TEXT = {
    "front": "stands in front and is very hard to move",
    "knows": "knows things and reads what nobody else can read",
    "talks": "talks their way out and gets people to do things",
    "unseen": "nobody sees coming and is already inside",
    "keeps": "keeps everyone standing and puts people back together",
    "out": "belongs outside, reads the ground, shoots from a long way off",
}
LOOK_TEXT = {"human": "Human", "elf": "Elf", "dwarf": "Dwarf",
             "small": "Halfling", "orc": "Orc", "drake": "Dragonborn",
             "other": "something they described out loud"}


def add_character(name, role=None, look=None, drive=None, session=0):
    """Ingest a character sheet. No names live in this file.

    Accepts what the picker produces. Call it with a decoded #c= fragment
    or with a JSON export from recall.html.
    """
    ids = []
    if role in ROLE_TEXT:
        ids.append(write("Is the one who " + ROLE_TEXT[role] + ".", name,
                         "HAPPENED", session, ["sheet", "role"]))
    if look in LOOK_TEXT:
        ids.append(write("Looks like " + LOOK_TEXT[look] + ".", name,
                         "HAPPENED", session, ["sheet", "look"]))
    if drive:
        ids.append(write(drive, name, "IMPROVISED", session,
                         ["sheet", "drive"]))
    return ids


def ingest(path, session=None):
    """Load a loom_recall.html JSON export. Returns rows written."""
    data = json.loads(Path(path).read_text())
    n = 0
    for m in data.get("memories", []):
        write(m.get("text", ""), m.get("subject", ""),
              m.get("kind", "HAPPENED"),
              session if session is not None else m.get("session", 0),
              [t for t in (m.get("tags") or "").split(",") if t],
              source="import")
        n += 1
    return n


# Fixtures for selftest only. Nothing else reads these.
SEED = [
    ("Bailey", 1, "HAPPENED", ["proud"],
     "Talked the toll keeper out of the bridge fee without a single roll"),
    ("Bailey", 1, "HAPPENED", [],
     "Picked the lock on the harbormaster's cabinet"),
    ("Bailey", 1, "IMPROVISED", ["next"],
     "Said she wants to find out who the toll keeper reports to"),
    ("Flynn", 1, "HAPPENED", ["proud"],
     "Held the doorway alone while the others got the crate out"),
    ("Flynn", 1, "IMPROVISED", [],
     "Named his sword Bootlace because it was tied to his pack"),
    ("Mike", 1, "HAPPENED", [],
     "Traded the brass fitting for a map of the cliff road"),
    ("", 1, "IMPROVISED", [],
     "The wireless station on the cliff answers on a frequency nobody sends"),
]


def selftest():
    """Prove the detector can return non-zero AND zero before trusting it."""
    if DB_PATH.exists():
        DB_PATH.unlink()
    for wal in (str(DB_PATH) + "-wal", str(DB_PATH) + "-shm"):
        if Path(wal).exists():
            Path(wal).unlink()

    ok = True

    def check(name, passed, detail=""):
        nonlocal ok
        ok = ok and passed
        print("  %-22s %s  %s" % (name, "PASS" if passed else "FAIL", detail))

    t0 = time.time()
    for subj, sess, kind, tags, text in SEED:
        write(text, subject=subj, kind=kind, session=sess, tags=tags,
              source="selftest")
    seeded = time.time() - t0

    st = stats()
    backend = ",".join(st["backends"]) or "none"
    check("seeded", st["total"] == len(SEED), "%d rows, %.2fs, backend %s"
          % (st["total"], seeded, backend))

    # KNOWN POSITIVE -- wording the log does not contain.
    hits = recall("the guy at the bridge", subject="Bailey", limit=3)
    top = hits[0]["text"] if hits else ""
    check("known_positive", "toll keeper" in top and "bridge fee" in top,
          repr(top[:52]))

    # KNOWN NEGATIVE -- nothing in the seed is about this.
    neg = recall("submarine cable landing station in Norway", limit=3)
    best = neg[0]["semantic"] if neg else 0.0
    check("known_negative", best < 0.55,
          "top semantic %.3f (must be low)" % best)

    # PERSONALIZATION -- same query, different player, different thread.
    b = recall("what did I do that worked", subject="Bailey", limit=1)
    f = recall("what did I do that worked", subject="Flynn", limit=1)
    check("personalized",
          b and f and b[0]["subject"] == "Bailey" and f[0]["subject"] == "Flynn",
          "%s vs %s" % (b[0]["subject"] if b else "-",
                        f[0]["subject"] if f else "-"))

    # SEMANTIC BEATS KEYWORD -- query shares no content word with the answer.
    sem = recall("who guarded the door", subject="Flynn", limit=1)
    check("semantic_over_keyword",
          sem and "doorway" in sem[0]["text"], repr(sem[0]["text"][:52]) if sem else "")

    # PROVENANCE FILTER
    imp = recall("sword", kinds=["IMPROVISED"], limit=5)
    check("kind_filter", all(h["kind"] == "IMPROVISED" for h in imp),
          "%d rows, all IMPROVISED" % len(imp))

    # THE BRIEF -- the thing Loom says before a session.
    br = brief("Bailey")
    check("brief", bool(br and br["wants"] and br["proud"]),
          "wants=%d proud=%d" % (len(br["wants"]), len(br["proud"])))

    t = time.time()
    recall("bridge", subject="Bailey")
    check("latency", (time.time() - t) < 1.0,
          "%.0f ms" % ((time.time() - t) * 1000))

    print()
    if br:
        print("  Loom would open with:")
        print("    Bailey. Last time you %s" % br["did"][-1][0].lower()
              + br["did"][-1][1:] + ".")
        if br["wants"]:
            print("    You said you wanted to %s"
                  % br["wants"][0].split("wants to ")[-1])
    print()
    print("  ALL PASS" if ok else "  FAILURES ABOVE")
    return 0 if ok else 1


# ----------------------------------------------------------------------- cli

def main():
    a = sys.argv[1:]
    if not a or a[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    cmd = a[0]

    def opt(flag, default=None):
        return a[a.index(flag) + 1] if flag in a else default

    if cmd == "selftest":
        return selftest()

    if cmd == "write":
        text = opt("--text")
        if not text:
            print("need --text")
            return 1
        mid = write(text,
                    subject=opt("--subject", ""),
                    kind=opt("--kind", "HAPPENED"),
                    session=int(opt("--session", "0")),
                    tags=(opt("--tags", "") or "").split(","),
                    source=opt("--source", "cli"))
        print("wrote %d" % mid)
        return 0

    if cmd == "recall":
        q = a[1] if len(a) > 1 else ""
        for h in recall(q, subject=opt("--subject"),
                        limit=int(opt("--limit", "5"))):
            print("  %.3f  [%s] %-8s s%d  %s"
                  % (h["score"], h["kind"][:4], h["subject"] or "-",
                     h["session"], h["text"]))
        return 0

    if cmd == "brief":
        br = brief(a[1] if len(a) > 1 else "")
        if not br:
            print("nothing yet")
            return 0
        print("%s -- last played session %d, %d memories"
              % (br["subject"], br["last_session"], br["total"]))
        for t in br["did"]:
            print("   did    " + t)
        for t in br["proud"]:
            print("   proud  " + t)
        for t in br["wants"]:
            print("   wants  " + t)
        return 0

    if cmd == "ingest":
        print("ingested %d" % ingest(a[1]))
        return 0

    if cmd == "stats":
        print(json.dumps(stats(), indent=2))
        return 0

    print("unknown command: " + cmd)
    return 1


if __name__ == "__main__":
    sys.exit(main())
