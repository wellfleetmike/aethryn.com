# loom

A Dungeons and Dragons game for Bailey and Flynn. Rules are SRD 5.2,
CC-BY-4.0 from Wizards.

## The one architectural rule

**Nothing in this tree points at the relay, and nothing in the relay points
here.**

The relay is archive and infrastructure work. This is a game. They are
separate on purpose. When they shared a parent directory, the boundary
became a written rule instead of a wall, and every rule got crossed within
two days. A different namespace is the wall.

If a file in here needs something from the relay, copy it in and note
where it came from. Do not reach across.

## Layout

    loom/
      index.html          the character picker. This is the URL.
      recall/
        index.html        the memory tool. Runs at the table.
      engine/
        loom_recall.py    box-side memory. Never served, never on the web.
      rules/              SRD PDF and JSON. Local only, gitignored.

## Static, and what that means

`index.html` and `recall/index.html` are self-contained. No build step, no
framework, no CDN, no backend, no browser storage. They work with the
network off and open by double-click. That is deliberate: the table may be
on bad cell service and the box may be asleep.

They go straight to Pages. Nothing needs to run for them to work.

    aethryn.com/loom/           the picker
    aethryn.com/loom/recall/    the memory tool

Bare paths, because a URL an eleven-year-old can type from memory is worth
more than a tidy filename.

## What is NOT static

`engine/loom_recall.py` runs on the box. It holds the real memory: party
files, session logs, everything the table said. That never goes to the web
and never goes in the repo -- see the gitignore.

The two halves talk through JSON export. `recall/index.html` captures at
the table, exports a file, and `loom_recall.py ingest` reads it. The page
is the lens, the box is the memory.

## The character link

The picker encodes a whole character into about 150 characters after `#c=`
in the URL. A kid taps "Copy my link" and sends it. That link opens cold in
any browser and restores the character, and pasting it into the memory tool
creates that character's memories.

It is transport across the air gap. It is not memory. Do not describe it as
memory.

## What memory actually is

The promise that lands is: *it already knows them.* Bailey sits down and it
has her name and remembers what she did last session.

That lives in the session logs and the party files, which do not exist
until session zero writes them. The magic is earned at the table, not
installed beforehand. Never build a feature that fakes it.

## Retrieval

Semantic, not keyword. A memory logged as "toll keeper" has to be findable
by "the guy at the bridge," because that is how an eleven-year-old will ask
for it three sessions later.

Identical math in the page and in the engine: hashed dual-channel vectors,
words for topic, character ngrams for morphology, blended with keyword
overlap. Pure stdlib, offline, no network call anywhere in the default
path.

Run `python3 engine/loom_recall.py selftest` before trusting it. It proves
a known positive AND a known negative, because a detector returning zero is
evidence of nothing until it has been shown it can return non-zero.

## Rules content

    SRD 5.2 PDF   sha256
    cf18e1f88a360646940b6fada63fd1bd04c1c02581ca668a9115c2f4577bf8aa

Never write a rules number from recollection. Recalled 5e is 2014-flavored
and reads as confident while being wrong. Traps that have already bitten:

    Channel Divinity      level 2, not 1. Cleric L1 is Divine Order.
    Deft Explorer         level 2, not 1. Ranger L1 is Favored Enemy.
    Fighter kit A         no shield.
    Bard and Rogue kit A  leather armor, not studded.
    Ritual Adept          the 2024 name.

No SRD 5.2 spells JSON exists anywhere, and the monsters JSON is a
three-entry stub. That is the state of the world, not a fetch failure. For
spells and monsters the PDF is the only source.

Attribution rides on anything carrying rules content:

    This work includes material from the System Reference Document 5.2
    ("SRD 5.2") by Wizards of the Coast LLC, available at
    https://www.dndbeyond.com/srd. Licensed under CC-BY-4.0.

## House rules

    Flynn has two Ls. Older files spell it wrong.
    Nobody at the table has played except Mike, and his last table was
    in the 1990s.
    All three humans are dyslexic. That decides structure, not styling.
    No character dies without a real chance to avoid it.
    The content ceiling is set at the youngest person at the table.

## Build order

    1. SRD on the box              done
    2. Picker                      done
    3. Memory and retrieval        done
    4. Session zero
    5. Everything else, AFTER a session has happened

Item 5 is a real constraint. Do not build what the table has not asked for.

## Strict ASCII

Everything written here is ASCII. Em-dashes and smart quotes are
contamination in this project, not style.
